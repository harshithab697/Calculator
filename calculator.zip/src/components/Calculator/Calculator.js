import { useEffect, useState, useCallback, useContext } from "react";
import CalcButton from "../CalcButton/CalcButton";
import { InputGroup, FormControl } from 'react-bootstrap';
import { debounce } from "lodash";
import { CalculatorContext } from "../../App";

const Calculator = () => {
    const [expression, setExpression] = useState("");
    const [displayexpression, setDisplayExpression] = useState("")
    const [useinput, setUserInput] = useState("")
    const [negationvalue, setNegationValue] = useState(false)

    const {setHistory} = useContext(CalculatorContext);

    const addExpression = (value, displayValue) => {
        setExpression((prev) => (prev + value))
        setDisplayExpression((prev) => (prev + displayValue))
    }
    const clearInput = () => {
        setExpression("")
        setDisplayExpression("")
    }
    const getInput = (e) => {
        setUserInput(e.target.value)
    }
    useEffect(() => {
        debouncedSetExpression(useinput)
    }, [useinput])

    const submitExpression = () => {
        console.log(expression)
        try {
            let result = eval(expression)
            setExpression(result)
            setDisplayExpression(result)
            setHistory((prev)=>([...prev, result]))
        } catch {
            console.log("invalid expression")
        }
    }

    const debouncedSetExpression = useCallback(
        debounce((useinput) => {
            setExpression(useinput)
        }, 500), []
    );

    const specialExpression = () => {
        setNegationValue(!negationvalue)
    }
    useEffect(() => {
        if (negationvalue === true) {
            setExpression((prev) => ("-" + prev))
            setDisplayExpression((prev) => ("-" + prev))
        } else {
            setExpression((prev) => (prev.slice(1,)))
            setDisplayExpression((prev) => (prev.slice(1,)))
        }
    }, [negationvalue])


    return (
        <>
            <div className="calculator">
                <InputGroup size="lg" className="calc_input ">
                    <FormControl aria-label="Large" aria-describedby="inputGroup-sizing-sm" style={{ "textAlign": "right" }} value={displayexpression} onChange={getInput} />
                </InputGroup>
                <div className="calc-wrapper">


                    <CalcButton position={3} onclick={clearInput}>CE</CalcButton>
                    <CalcButton position={3} onclick={addExpression} value={Math.sqrt(16)}>&#8730;x</CalcButton>
                    <CalcButton position={3} onclick={addExpression} value={"%"}>&#37;</CalcButton>
                    <CalcButton position={4} onclick={addExpression} value={"/"}>&#247;</CalcButton>


                    <CalcButton onclick={addExpression} value={7}>7</CalcButton>
                    <CalcButton onclick={addExpression} value={8}>8</CalcButton>
                    <CalcButton onclick={addExpression} value={9}>9</CalcButton>
                    <CalcButton position={4} onclick={addExpression} value={"*"}>&#215;</CalcButton>


                    <CalcButton onclick={addExpression} value={4}>4</CalcButton>
                    <CalcButton onclick={addExpression} value={5}>5</CalcButton>
                    <CalcButton onclick={addExpression} value={6}>6</CalcButton>
                    <CalcButton onclick={addExpression} position={4} value={"-"}>&#8722;</CalcButton>


                    <CalcButton onclick={addExpression} value={3}>3</CalcButton>
                    <CalcButton onclick={addExpression} value={2}>2</CalcButton>
                    <CalcButton onclick={addExpression} value={1}>1</CalcButton>
                    <CalcButton onclick={addExpression} position={4} value={"+"}>&#43;</CalcButton>


                    <CalcButton onclick={addExpression} value={0}>0</CalcButton>
                    <CalcButton onclick={addExpression} value={"."}>.</CalcButton>
                    <CalcButton onclick={specialExpression} value={"negation"}>+/-</CalcButton>
                    <CalcButton onclick={submitExpression} position={4}>&#8316;</CalcButton>


                </div>
            </div>
        </>
    )
}
export default Calculator ;